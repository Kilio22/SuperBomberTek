/*
** EPITECH PROJECT, 2019
** editor
** File description:
** main.cpp
*/

#include "Editor.hpp"


int main() {
    Editor win;

    win.loop();
    return (0);
}